This folder contains the exact modified upstream source files used to produce
the iOS Codex binary in this repo.

Canonical patch: ../patches/0001-ios-codex.patch
